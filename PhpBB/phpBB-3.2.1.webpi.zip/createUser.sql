/**********************************************************************/
/* createUser.sql                                                     */
/* Creates a login and makes the user a member of db roles            */
/*                                                                    */
/*           Modifications for SQL AZURE  - ON USER DB                */
/*                                                                    */
/*           NOTICE OF LICENSE                                        */
/* Copyright (C) Microsoft Corporation All rights reserved.           */
/*                                                                    */
/* This program is free software; you can redistribute it and/or      */
/* modify it under the terms of the                                   */
/* GNU General Public License version 2 as published by the           */
/* Free Software Foundation.                                          */
/* This program is distributed in the hope that it will be useful,    */
/* but WITHOUT ANY WARRANTY; without even the implied warranty        */
/* of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.            */
/* See the GNU General Public License for more details.               */
/*                                                                    */
/* You should have received a copy of the GNU General Public License  */
/* along with this program; if not, write to the                      */
/* Free Software Foundation, Inc., 59 Temple Place, Suite 330,        */
/* Boston, MA 02111-1307 USA                                          */
/**********************************************************************/



-- Create database user and map to login
-- and add user to the datareader, datawriter, ddladmin and securityadmin roles
--

    CREATE USER PlaceHolderForUser FOR LOGIN PlaceHolderForUser;
	GO
    EXEC sp_addrolemember 'db_owner', PlaceHolderForUser;
    GO