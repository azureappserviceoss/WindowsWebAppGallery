DECLARE @admin_password NVARCHAR(100);
SELECT @admin_password = LOWER(CONVERT(NVARCHAR(100),HashBytes('MD5', 'PlaceHolderForAdminPass'),2));


DECLARE @err1 int, @rowcount1 int

UPDATE #__users SET 
	name = 'Super User', 
	username = 'PlaceHolderForAdminUser', 
	email = 'PlaceHolderForAdminEmail', 
	password = @admin_password, 
	block = 0, 
	sendEmail = 1, 
	registerDate = CURRENT_TIMESTAMP, 
	lastvisitDate = CURRENT_TIMESTAMP, 
	activation = '', 
	params = ''
	WHERE id = 42;
	
set @rowcount1 = @@ROWCOUNT
set @err1 = @@ERROR

IF @err1 <> 0
	PRINT N'ERROR in  users'
ELSE
	BEGIN		
		IF @rowcount1 = 0
		BEGIN		
		SET IDENTITY_INSERT #__users ON
		INSERT INTO #__users ( id,
			name,
			username,
			email,
			password,
			block,
			sendEmail,
			registerDate,
			lastvisitDate,
			activation,
			params )
			VALUES ( 42, 
			'Super User',
			'PlaceHolderForAdminUser',
			'PlaceHolderForAdminEmail', 
			@admin_password, 
			0, 
			1, 
			CURRENT_TIMESTAMP, 
			CURRENT_TIMESTAMP, 
			'', 
			'');
		SET IDENTITY_INSERT #__users OFF
		END
END
GO


DECLARE @err2 int, @rowcount2 int

UPDATE #__user_usergroup_map SET 
	group_id = 8
	WHERE user_id = 42;
	
set @rowcount2 = @@ROWCOUNT
set @err2 = @@ERROR

IF @err2 <> 0
	PRINT N'ERROR in  usergroup'
ELSE
	BEGIN		
		IF @rowcount2 = 0
		BEGIN				
		INSERT INTO #__user_usergroup_map ( user_id,
			group_id )
			VALUES ( 42, 8 );
		END
END
GO
