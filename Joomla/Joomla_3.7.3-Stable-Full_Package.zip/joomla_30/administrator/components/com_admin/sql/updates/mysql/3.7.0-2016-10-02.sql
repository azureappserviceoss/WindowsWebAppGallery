ALTER TABLE `#__session` MODIFY `client_id` tinyint(3) unsigned DEFAULT NULL;
