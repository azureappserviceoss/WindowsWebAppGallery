DROP PROCEDURE IF EXISTS load_admin_user $$

CREATE PROCEDURE load_admin_user()
BEGIN
DECLARE CONTINUE HANDLER FOR SQLSTATE '23000' BEGIN END;


REPLACE INTO #__users SET
	id = 42, 
	name = "Super User", 
	username = "PlaceHolderForAdminUser", 
	email = "PlaceHolderForAdminEmail", 
	password = MD5("PlaceHolderForAdminPass"), 
	block = 0, sendEmail = 1, 
	registerDate = now(), 
	lastvisitDate = "0000-00-00 00:00:00", 
	activation = "", 
	params = "";

REPLACE INTO #__user_usergroup_map SET user_id = 42, group_id = 8;



END
$$

CALL load_admin_user()$$
DROP PROCEDURE IF EXISTS load_admin_user $$

			
				
